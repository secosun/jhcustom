Commerce Alipay
===============

Implements [Alipay](http://www.alipay.com) payment services
for use with [Drupal Commerce](http://drupal.org/project/commerce).

---

Features
---------

- Direct Pay

_TODO [Commerce Delivery](http://drupal.org/project/commerce)_

- Escrow Pay
- Dual Function
- Send Goods Confirm


