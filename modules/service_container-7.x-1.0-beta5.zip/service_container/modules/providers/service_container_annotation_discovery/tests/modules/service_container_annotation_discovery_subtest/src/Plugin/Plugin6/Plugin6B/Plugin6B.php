<?php

namespace Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin6\Plugin6B;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin6B
 *
 * @Plugin(
 *   id = "Plugin6B",
 *   label = "Label Plugin6B"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin6\Plugin6B
 */
class Plugin6B extends PluginBase {

}
