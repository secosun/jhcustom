<?php

namespace Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin5\Plugin5A;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin5A
 *
 * @Plugin(
 *   id = "Plugin5A",
 *   label = "Label Plugin5A"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin5\Plugin5A
 */
class Plugin5A extends PluginBase {

}
