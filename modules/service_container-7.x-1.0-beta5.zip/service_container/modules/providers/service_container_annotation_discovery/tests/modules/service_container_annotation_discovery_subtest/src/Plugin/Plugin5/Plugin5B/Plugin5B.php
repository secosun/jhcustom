<?php

namespace Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin5\Plugin5B;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin5B
 *
 * @Plugin(
 *   id = "Plugin5B",
 *   label = "Label Plugin5B"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin5\Plugin5B
 */
class Plugin5B extends PluginBase {

}
