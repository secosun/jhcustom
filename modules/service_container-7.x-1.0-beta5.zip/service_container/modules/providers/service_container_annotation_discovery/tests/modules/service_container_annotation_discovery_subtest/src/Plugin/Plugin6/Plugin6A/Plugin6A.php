<?php

namespace Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin6\Plugin6A;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin6A
 *
 * @Plugin(
 *   id = "Plugin6A",
 *   label = "Label Plugin6A"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_subtest\Plugin\Plugin6\Plugin6A
 */
class Plugin6A extends PluginBase {

}
