<?php

namespace Drupal\service_container_annotation_discovery_test\Plugin\Plugin2\Plugin2B;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin2B
 *
 * @Plugin(
 *   id = "Plugin2B",
 *   label = "Label Plugin2B"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_test\Plugin\Plugin2\Plugin2B
 */
class Plugin2B extends PluginBase {

}
