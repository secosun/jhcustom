<?php

namespace Drupal\service_container_annotation_discovery_test\Plugin\Plugin2\Plugin2A;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin2A
 *
 * @Plugin(
 *   id = "Plugin2A",
 *   label = "Label Plugin2A"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_test\Plugin\Plugin2\Plugin2A
 */
class Plugin2A extends PluginBase {

}
