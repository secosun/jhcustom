<?php

namespace Drupal\service_container_annotation_discovery_test\Plugin\Plugin1\Plugin1A;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin1A
 *
 * @Plugin(
 *   id = "Plugin1A",
 *   label = "Label Plugin1A"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_test\Plugin\Plugin1\Plugin1A
 */
class Plugin1A extends PluginBase {

}
