<?php

namespace Drupal\service_container_annotation_discovery_test\Plugin\Plugin1\Plugin1B;

use Drupal\Component\Annotation\Plugin;
use Drupal\Component\Plugin\PluginBase;

/**
 * Class Plugin1B
 *
 * @Plugin(
 *   id = "Plugin1B",
 *   label = "Label Plugin1B"
 * )
 *
 * @package Drupal\service_container_annotation_discovery_test\Plugin\Plugin1\Plugin1B
 */
class Plugin1B extends PluginBase {

}
