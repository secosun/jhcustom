### How to run the tests

````
./tests/run-tests.sh
````

The tests are in a subdirectory to not clutter the main module space with composer, etc.
Composer is only needed to run the tests.
