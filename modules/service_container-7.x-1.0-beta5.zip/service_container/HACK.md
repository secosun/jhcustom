## List of classes that we've altered ##
 - Database:
   - Drupal\Core\Database\Connection
   - Drupal\Core\Database\Database
   - Drupal\Core\Database\Query\Merge
 - FileCache:
   - Drupal\Component\FileCacheFactory (PHP 5.3 friendly)
   - Drupal\Component\NullFileCache (PHP 5.3 friendly)
 - KeyValueStore:
   - Drupal\Core\KeyValueStore\DatabaseStorage
 - StringTranslation:
   - Drupal\Core\StringTranslation\TranslationWrapper

## List of class that we've added ##
 -Drupal\Core\DependencyInjection\Dumper\PhpArrayDumper
