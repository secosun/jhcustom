<?php

namespace Drupal\xautoload_test_1;

class ExampleClass {}
