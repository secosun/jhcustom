<?php

namespace Drupal\testmod_psr4_custom;

class Foo {}
