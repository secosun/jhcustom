<?php


namespace Drupal\xautoload_test_5\FooNamespace;


class Foo_Class {

} 
