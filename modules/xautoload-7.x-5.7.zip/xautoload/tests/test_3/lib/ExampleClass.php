<?php

namespace Drupal\xautoload_test_3;

class ExampleClass {}
