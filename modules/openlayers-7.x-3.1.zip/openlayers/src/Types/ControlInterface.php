<?php
/**
 * @file
 * Interface ControlInterface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface ControlInterface.
 */
interface ControlInterface extends ObjectInterface {

}
