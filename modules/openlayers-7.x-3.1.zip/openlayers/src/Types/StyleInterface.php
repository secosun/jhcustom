<?php
/**
 * @file
 * Interface StyleInterface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface StyleInterface.
 */
interface StyleInterface extends ObjectInterface {

}
