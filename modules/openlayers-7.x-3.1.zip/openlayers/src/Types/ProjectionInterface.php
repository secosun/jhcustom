<?php
/**
 * @file
 * Interface ProjectionInterface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface ProjectionInterface.
 */
interface ProjectionInterface extends ObjectInterface {

}
