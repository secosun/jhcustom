<?php
/**
 * @file
 * Layer: Image.
 */

namespace Drupal\openlayers\Plugin\Layer\Image;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Layer;

/**
 * Class Image.
 *
 * @OpenlayersPlugin(
 *  id = "Image"
 * )
 */
class Image extends Layer {

}
