Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.Style:Invisible',
  init: function(data) {
    return [
      new ol.style.Style()
    ];
  }
});
