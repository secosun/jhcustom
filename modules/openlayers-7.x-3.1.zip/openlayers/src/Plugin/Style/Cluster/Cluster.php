<?php
/**
 * @file
 * Style: Cluster.
 */

namespace Drupal\openlayers\Plugin\Style\Cluster;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Style;

/**
 * Class Cluster.
 *
 * @OpenlayersPlugin(
 *  id = "Cluster"
 * )
 */
class Cluster extends Style {
  //TODO: Provide options to let user customize the cluster style.

}
