<?php
/**
 * @file
 * Interaction: Pointer.
 */

namespace Drupal\openlayers\Plugin\Interaction\Pointer;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Interaction;

/**
 * Class Pointer.
 *
 * @OpenlayersPlugin(
 *  id = "Pointer"
 * )
 */
class Pointer extends Interaction {

}
