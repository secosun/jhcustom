<?php
/**
 * @file
 * Interaction: PinchZoom.
 */

namespace Drupal\openlayers\Plugin\Interaction\PinchZoom;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Interaction;

/**
 * Class PinchZoom.
 *
 * @OpenlayersPlugin(
 *  id = "PinchZoom"
 * )
 */
class PinchZoom extends Interaction {

}
