<?php
/**
 * @file
 * Interaction: Draw.
 */

namespace Drupal\openlayers\Plugin\Interaction\Draw;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Interaction;

/**
 * Class Draw.
 *
 * @OpenlayersPlugin(
 *  id = "Draw"
 * )
 */
class Draw extends Interaction {

}
