<?php
/**
 * @file
 * Component: ViewSync.
 */

namespace Drupal\openlayers_library\Plugin\Component\ViewSync;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Openlayers;
use Drupal\openlayers\Types\Component;
use Drupal\openlayers\Types\ObjectInterface;

/**
 * Class ViewSync.
 *
 * @OpenlayersPlugin(
 *   id = "ViewSync"
 * )
 */
class ViewSync extends Component {

}
