Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.Component:blocklayerswitcher',
  init: function(data) {}
});
