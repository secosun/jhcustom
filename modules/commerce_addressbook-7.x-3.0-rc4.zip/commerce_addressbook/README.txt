Commerce Addressbook is a module that allows authenticated customers to reuse
previously entered addresses during checkout.

Note that for data consistency reasons editing a previously entered address
won't change it on previously made orders.

Installation
============
* Enable the Commerce Addresbook module
* The "Addresses on File" select list should now automatically be attached to the checkout form.
* Enable "create", "edit", and "view" permissons for each profile type addressbook was enabled on.
